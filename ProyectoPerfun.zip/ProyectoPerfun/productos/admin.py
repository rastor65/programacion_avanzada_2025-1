from django.contrib import admin
from .models import Perfume

admin.site.register(Perfume)

# Register your models here.
