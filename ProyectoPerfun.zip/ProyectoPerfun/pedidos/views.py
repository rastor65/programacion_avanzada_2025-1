from rest_framework import generics, permissions
from .models import Pedido
from .serializers import PedidoSerializer

class CrearPedidoView(generics.CreateAPIView):
    queryset = Pedido.objects.all()
    serializer_class = PedidoSerializer
    permission_classes = [permissions.IsAuthenticated]

    def perform_create(self, serializer):
        serializer.save(usuario=self.request.user.perfil)


# Create your views here.
