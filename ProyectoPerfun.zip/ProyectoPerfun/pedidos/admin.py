from django.contrib import admin
from .models import Pedido, PedidoProducto

admin.site.register(Pedido)
admin.site.register(PedidoProducto)


# Register your models here.
