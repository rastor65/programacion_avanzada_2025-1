#Genera una lista con los primeros 20 números pares y luego muestra la
#listajuntoconlasumadetodossuselementos.
numeros_pares = [num for num in range(2, 41, 2)]

suma_pares = sum(numeros_pares)


print("Lista de los primeros 20 números pares:", numeros_pares)
print("Suma de todos los elementos:", suma_pares)