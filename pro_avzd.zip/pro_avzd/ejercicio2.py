#Pide al usuario un número y genera su tabla de multiplicar del 1 al 12.
#Permite al usuario decidir si la tabla se imprime en formato horizontal o
#vertical.
numero = int(input("Introduce un número de la tabla de multiplicar: "))

formato = input("¿Quieres horizontal o vertical? ").strip().lower()

if formato == 'h':
    
    tabla = [numero * i for i in range(1, 13)]
    print(" | ".join(map(str, tabla)))
elif formato == 'v':
    
    for i in range(1, 13):
        print(f"{numero} x {i} = {numero * i}")
else:
    print("Formato no válido. escoge 'h' o 'v'.")