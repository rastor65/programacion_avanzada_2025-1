#Genera una lista con los primeros 20 números pares y luego muestra la
#lista junto con la suma de todos sus elementos.
numeros_pares = [num for num in range(2, 41, 2)]
suma_pares = sum(numeros_pares)

print("Lista de los primeros 20 números pares:", numeros_pares)
print("Suma de todos los elementos de la lista:", suma_pares)