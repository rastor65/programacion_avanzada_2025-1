#Optimiza el código para que no tenga que comprobar todos los
#números hasta n,sino solo hasta su raíz cuadrada.

import math

def es_primo(n):
    if n < 2: return False
    return all(n % i != 0 for i in range(2, math.isqrt(n) + 1))

while True:
    try:
        num = int(input("pon un número: "))
        print(f"El número {num} es {'primo' if es_primo(num) else 'no primo'}.")
        break
    except ValueError:
        print("tienes que meter un número entero.")


