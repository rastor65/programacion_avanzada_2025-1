#Escribe un programa que solicite la edad del usuario e indique si es niño (0-12 años), 
# adolescente (13-17 años), adulto (18-64 años) o adulto mayor (65+ años). Además, imprime un mensaje motivacional acorde a laedad.

edad = int(input("Por favor, ingresa tu edad: "))

if 0 <= edad <= 12:
    print("Eres un niño. ¡Nunca dejes de soñar y jugar!")
elif 13 <= edad <= 17:
    print("Eres un adolescente. ¡Cree en ti mismo y persigue tus metas!")
elif 18 <= edad <= 64:
    print("Eres un adulto. ¡El esfuerzo y la perseverancia te llevarán lejos!")
elif edad >= 65:
    print("Eres un adulto mayor. ¡Tu experiencia es un tesoro invaluable!")
else:
    print("Edad no válida. Por favor, ingresa un número positivo.")