#Un profesor quiere dividir 32 lápices entre todos los estudiantes de su
#grupo y quiere saber cuántos lápices le sobran.

estudiantes=int(input("ingrese el numero de estudiantes: "))
lapices=32
lapices_que_le_sobran=lapices % estudiantes

print("el profesor le sobran", lapices_que_le_sobran,"lapices ")
