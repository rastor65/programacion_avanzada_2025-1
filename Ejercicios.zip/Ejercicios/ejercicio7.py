#Estás analizando comentarios de clientes para un producto. Necesitas
#contar cuántas veces se menciona la palabra "excelente" eliminar
#espaciosinnecesarios ymostrarelcomentarioenminúsculas.

comentarios = input("Ingrese su comentario acerca del producto : ")

contador_excelente = 0


comentarios = comentarios.strip()  
comentarios = comentarios.lower()  
contador_excelente += comentarios.count('excelente')  

print(f'La palabra "excelente" se menciona {contador_excelente} veces.')