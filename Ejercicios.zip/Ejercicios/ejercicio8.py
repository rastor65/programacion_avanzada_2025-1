#Enunciado: Eres un editor de noticias y necesitas corregir un artículo.
#Debes reemplazar todas las menciones de "tecnología antigua" por
#"tecnología de punta" y dividir el artículo en oraciones.

articulo = """La tecnología antigua ha sido reemplazada por nuevos avances.
Muchas empresas siguen utilizando tecnología antigua en sus procesos. 
Sin embargo, la tecnología de punta está avanzando rápidamente."""

articulo_corregido = articulo.replace("tecnología antigua", "tecnología de punta")

oraciones = articulo_corregido.split(". ")

for i, oracion in enumerate(oraciones, 1):
    print(f"Oración {i}: {oracion.strip()}.")

