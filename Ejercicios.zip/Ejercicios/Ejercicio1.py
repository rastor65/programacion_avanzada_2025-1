
#Un chef tiene un presupuesto inicial. Y para su receta necesita comprar
#vegetales, carne y especias. Finalmente, si los gastos no superan el
#presupuesto,puedeagregarfrutas.

def compra(presupuesto,vegetales,carne,especias):
    
    gastos = vegetales+carne+especias
    
    if gastos > presupuesto:
        print ("El presupuesto fue excedido")
    
    elif gastos < presupuesto:
        print("Puedes agregar frutas a la compra")
        
        
    
 


#Variables
presupuesto = int(input("Ingrese el presupuesto disponible: "))


vegetales = int(input("valor de los vegetales: "))
carne = int(input("valor de la carne: "))
especias = int(input("valor de las especies: "))
frutas = int(input("valor de las frutas: "))


compra(presupuesto,vegetales,carne,especias)

print("ingrese el producto a comprar:")



