#Enunciado: Estás trabajando en un sistema de inventario. Necesitas
#verificar si un código de producto ingresado por el usuario es válido. Un
#código válido debe comenzar con lasletras"PRO" (en mayúsculas). Si el
#código es válido, muestra un mensaje de "Código válido". De lo
#contrario,muestra"Códigoinválido".

codigo_producto = input("Ingrese el código de producto: ")
codigo_producto = codigo_producto.upper()

if codigo_producto.startswith("PRO") == True:
    print("Codigo valido")
else:
    print("Codigo no valido")