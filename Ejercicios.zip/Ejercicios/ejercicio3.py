#un grupo de estudiantes necesita dividirse en equipos. pidele al usuario que ingrese el numero total de estudiantes y cuantos
#estudiantes de haber por equipo

numero_estudiantes=int(input("ingrese en numero total de estudiantes: "))
numero_estudiantes_por_equipo=int(input("ingrese el numero de estudiantes por equipo: "))
numero_de_equipos_completos=numero_estudiantes // numero_estudiantes_por_equipo

print("se pueden formar", numero_estudiantes_por_equipo,"equipos ya completos")
