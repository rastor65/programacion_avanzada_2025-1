texto = input("diga su articulo ")
texto_modificado = texto.replace("tecnologia antigua", "tecnologia de punta")
print(texto_modificado)