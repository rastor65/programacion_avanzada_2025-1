x = float(input("diga el largo"))
y = float(input("diga el ancho "))
area = (x * y)
print(f"el area del terreo rectangular es de {area}")